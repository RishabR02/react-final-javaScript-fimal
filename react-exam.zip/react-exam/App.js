import BgColor from "./pages/bColor"
import ConditionalRendering from "./pages/ConditionalRendering"
import Counter from "./pages/Counter"
import Form from "./pages/Form"
import ListandKeys from "./pages/ListandKeys"
import Main from "./pages/NameAsProps"
import ShoppingCart from "./pages/shoppingCart"
import UseEffectDemo from "./pages/useEffect"
import WelecomeToReact from "./pages/WelcomeToReact"
import Parent from "./ParentChild/Parent"
import Home from "./useContext/Home"
import ThemeProvider  from "./useContext/ThemeProvider"
import Counter1 from "./useContext/useReducer"
function App(){
  return(
   
      <ThemeProvider>
      <WelecomeToReact/><br/>
      ------------------------------------------------------------------------------------
      2program<Main/><br/>
      ------------------------------------------------------------------------------------
      3program<Counter/><br/>
      ------------------------------------------------------------------------------------
      4program<ListandKeys/><br/>
      ------------------------------------------------------------------------------------
      5program<Form/><br/>
      ------------------------------------------------------------------------------------
      <ConditionalRendering/><br/>
      ------------------------------------------------------------------------------------
      <Parent/><br/>
      ------------------------------------------------------------------------------------
      <UseEffectDemo/><br/>
      ------------------------------------------------------------------------------------
      <BgColor/><br/>
      ------------------------------------------------------------------------------------
      <Home/><br/>
      ------------------------------------------------------------------------------------
      <Counter1/><br/>
      ------------------------------------------------------------------------------------
      <ShoppingCart/>
      </ThemeProvider>
  
  )
}

export default App