import { useReducer } from "react";

// 1️⃣ Reducer function
function reducer(state, action) {
  if (action === "increment") return state + 1;
  if (action === "decrement") return state - 1;
  return state;
}

function Counter1() {
  // 2️⃣ useReducer Hook
  const [count, dispatch] = useReducer(reducer, 0); // 0 = initial state

  return (
    <div style={{ padding: "20px" }}>
      <h2>Count: {count}</h2>
      <button onClick={() => dispatch("increment")}>Increment</button>
      <button onClick={() => dispatch("decrement")}>Decrement</button>
    </div>
  );
}

export default Counter1;