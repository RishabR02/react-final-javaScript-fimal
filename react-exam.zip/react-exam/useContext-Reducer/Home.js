import { useContext } from "react";
import  ThemeContext  from "./ThemeContext";

function Home() {
  const { theme, toggleTheme } = useContext(ThemeContext);

  const style = {
  backgroundColor: theme === "light" ? "white" : "gray",
  color: theme === "light" ? "black" : "white",
  minHeight: "100vh",
  padding: "20px"
};


  return (
    <div style={style}>
      <h2>Current Theme: {theme}</h2>
      <button onClick={toggleTheme}>Change Theme</button>
    </div>
  );
}

export default Home;
