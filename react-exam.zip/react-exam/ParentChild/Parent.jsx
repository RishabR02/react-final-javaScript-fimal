import Child from "./Child"

function Parent () {
  return (
    <div>
      <h1>This is Parent Class</h1>
      <Child name="Rizz"/>
      <Child name="Messi"/>
    </div>
  )
}

export default Parent
