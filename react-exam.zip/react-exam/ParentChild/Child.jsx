
function Child (props) {
  return (
    <div>
      <p>Hello {props.name} from Child class</p>
    </div>
  )
}

export default Child
