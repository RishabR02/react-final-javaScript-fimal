import React, { useState } from 'react'

function Form () {

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");

    const handleSubmit = (e) =>{
        e.preventDefault();
        alert(` Name: ${name} Email: ${email}`)
    }
  return (
    <div>
        <h2>React Controlled Form</h2>
        <form onSubmit={handleSubmit}>
            <div>
                <input type='text' value={name} placeholder='Enter' onChange={(e) => setName(e.target.value)}/>
                <input type='email' value={email} placeholder='Enter email' onChange={(e)  =>setEmail(e.target.value)}/>
            </div>
            <div>
                <button type='submit'>Submit</button>
            </div>
        </form>
      
    </div>
  )
}


export default Form
