import { useEffect } from "react"

function UseEffectDemo () {
useEffect  (() =>{
    console.log("Component Mounted")
}, [])

  return (
    <div>
<h1>Check the Console</h1>
      <p>Open your browser console to see the message.</p>    </div>
  )
}

export default UseEffectDemo
