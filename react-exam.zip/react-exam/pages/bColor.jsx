import React, { useState } from 'react'

const BgColor = () => {
    const [ bgColor, setBgColor] = useState("");

    
    const changeColor =() =>{
            const colors = ['blue', 'yellow','orange', 'red', 'black', 'violet']
            const randomColor = colors[ Math.floor (Math.random() *  colors.length)]
            setBgColor(randomColor)
    }
  return (
    <div style={{backgroundColor: bgColor, height: "100vh", textAlign: "center",
paddingTop: "50px" }}>
      <h2>Change BG Color </h2>
      <h2>Click the below button</h2>
      <button onClick={changeColor}>Change Color</button>

    </div>
  )
}

export default BgColor
