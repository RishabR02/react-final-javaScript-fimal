import { useState } from "react"

function ConditionalRendering() {
    const [ isLoggedIn, setIsLoggedIn] = useState(false);

    const toggleLogin = () =>{
        setIsLoggedIn(!isLoggedIn)
    }
  return (
    <div>
      <h2>Conditional Rendring</h2>
      { isLoggedIn ?
    (<p>Login Successfull</p>
    ):( 
    <p> Please Login</p>
    )}
    <button onClick={toggleLogin}>
        { isLoggedIn ? "Logout" : "Login"}
    </button>
    </div>
  )
}

export default ConditionalRendering
