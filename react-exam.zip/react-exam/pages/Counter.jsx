import { useState } from "react"

function Counter  ()  {
  const [ count, setCount]=useState(0);

  const handleIncrement =() =>{
    setCount(count + 1);
  }
  const handleDecrement=()=>{
    setCount(count-1);
  }
  const handleReset =()=>{
    setCount(0);
  }
    return (
    <div style={{textAlign:"center", marginTop:'50px'}}>  
    <h1>Counter App</h1>
        <h2>Count {count}</h2>
        <button onClick={handleIncrement} style={{marginLeft: '0px 50px'}}>Increment</button>
        <button onClick={handleDecrement} >Decrement</button><br/>
        <button onClick={handleReset} style={{marginTop:'20px'}}>Reset</button>
    </div>
  )
}

export default Counter
