
function NameAsProps  (props)  {
return(
    <h2>Hello, {props.name}</h2>
)
}

function Main(){
    return(
        <div>
            <h1>Calling Name As Prop</h1>
            <NameAsProps name="Rizz"/>
            <NameAsProps name="messi"/>
        </div>
    )
}
export default Main