function BankAccount(name, balance) {
  this.name = name;
  this.balance = balance;

  this.deposit = amt => {
    this.balance += amt;
    console.log(`${this.name} deposited ₹${amt}. New Balance: ₹${this.balance}`);
  };

  this.withdraw = amt => {
    if (amt <= this.balance) {
      this.balance -= amt;
      console.log(`${this.name} withdrew ₹${amt}. New Balance: ₹${this.balance}`);
    } else {
      console.log(`❌ Not enough balance for ${this.name}!`);
    }
  };

  this.show = () =>
    console.log(`👤 Name: ${this.name}, 💰 Balance: ₹${this.balance}`);
}

// create accounts
let acc1 = new BankAccount("Adani", 1000);
let acc2 = new BankAccount("Modi", 5000);

// use methods
acc1.show();
acc1.deposit(500);
acc1.withdraw(300);

acc2.show();
acc2.withdraw(6000);
