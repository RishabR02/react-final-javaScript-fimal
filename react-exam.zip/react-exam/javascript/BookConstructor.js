function Book(name, available) {
  this.name = name;
  this.available = available;
}

const library = {
  books: [],

  get count() {
    return this.books.filter(b => b.available).length;
  },

  set updateStatus({ name, status }) {
    const book = this.books.find(b => b.name === name);
    if (book) book.available = status;
  },

  showBooks() {
    console.log("📚 Library Books:");
    this.books.forEach(b =>
      console.log(`- ${b.name} (${b.available ? "Available" : "Not Available"})`)
    );
    console.log("👉 Total Available:", this.count);
  }
};

// Add books
library.books.push(
  new Book("Java", true),
  new Book("HTML", false),
  new Book("Python", true)
);

console.log("Before update:");
library.showBooks();

library.updateStatus = { name: "HTML", status: true };

console.log("\nAfter update:");
library.showBooks();
